	<div id="footer">

		<img src="facebook.jpg" width="30px" height="30px"/> 
		<img src="twitter.jpg" width="30px" height="30px"/> 
		<img src="googleplus.jpg" width="30px" height="30px"/> 

	</div>


</body>

</html>
