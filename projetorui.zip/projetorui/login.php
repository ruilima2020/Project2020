<?php 	include('header0.php'); 
$result="";
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	//grab values email and password from login form:

	$login_email = mysqli_real_escape_string($dbc, trim($_POST['email']));
	$login_password = mysqli_real_escape_string($dbc, $_POST['password']);

	//create the query and number of rows returned from the query:

	$query = mysqli_query($dbc, "SELECT * FROM users WHERE email='$login_email' AND passe='$login_password'");
	$numrows = mysqli_num_rows($query);
	if($numrows != 0){
		$row = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$_SESSION['user_id']=$row['id'];
		$_SESSION['user_name']=$row['nome'];
		header('location:themes.php');
	}else{
		$result="<h4 style='color:red;'>ERROR: Your password and/or email is incorrect!</h4>";
	}
}

if(isset($_GET['nologin'])) $result="<h4 style='color:blue;'>Please Login to buy our books!</h4>";

?>
		<section>
			<div class="page-header" id="section-contact">
				<h2>Login</h2>
				<small>Login with our store to be able to buy our books and keep up to date on the best products, promotions and news! If you are not registered, please <a href="register.php">Register Here</a>.</small>
				<?php echo $result; ?>
			</div>
			<div class="row">

				<div class="col-lg-2">
				</div>
				<div class="col-lg-8">
					<form action="login.php" method="POST" class="form-horizontal" role="form">
						<div class="form-group">
							<label for="contact-email" class="col-lg-2 control-label">Email</label>
							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-email" placeholder="Email" name="email" required>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-Password" class="col-lg-2 control-label">Password</label>

							<div class="col-lg-10">
								<input type="password" class="form-control" id="contact-Password" placeholder="Password" name="password" required>
							</div>
						</div>
						
						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
								<button type="submit" class="btn btn-primary">Login</button> 
							</div>
						</div> 

					</form>
					
				</div>

			</div>

		</section>

	</div> <!-- end container -->
<?php 	include('footer0.php'); ?>
