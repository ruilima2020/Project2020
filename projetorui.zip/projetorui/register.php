<?php 	include('header0.php'); 
$result="";
//check if user submitted form:
if($_SERVER['REQUEST_METHOD'] == 'POST'){

//grab all data from the submitted form:
$fname = $_POST['nome'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$password = $_POST['password'];
$morada = $_POST['morada'];
$localidade = $_POST['localidade'];
$cpostal = $_POST['cpostal'];

//check if all form values in variables are not empty:
	if(!empty($fname) && !empty($email) && !empty($gender) && !empty($age) && !empty($password)  && !empty($morada) && !empty($localidade) && !empty($cpostal)){

		//query to database to insert on users table all values from form:
		mysqli_query($dbc, "INSERT INTO users(nome,email,gender,age,passe, morada,localidade,cpostal) VALUES('$fname','$email','$gender','$age','$password','$morada','$localidade','$cpostal')");

		//number of rows affected:
		$registered = mysqli_affected_rows($dbc);

		$result="<div class='page-header' id='section-contact'>
				<small style='color:green;'>You have registered successfully! Please login.</small>
			</div>";
	}else{
		$result="<div class='page-header' id='section-contact'>
				<small style='color:red;'>ERROR: you left some values in blank!</small>
			</div>";
	}
}

?>
		<section>
<?php echo $result; ?>
			<div class="row">

				<div class="col-lg-4">
					<h2>Register</h2>
					<br>
					<br>
					<h4>Register with our store to be able to buy our books and keep up to date on the best products, promotions and news! If you are already registered, please <a href="login.php">Login</a>.</h4>

				</div>
				<div class="col-lg-8">
					<form action="register.php" method="POST" class="form-horizontal" role="form">
						<div class="form-group">
							<label for="contact-name" class="col-lg-2 control-label">Name</label>
							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-name" name="nome" placeholder="Name" required>
							</div>
						</div>

						<div class="form-group">
							<label for="contact-email" class="col-lg-2 control-label">Email</label>

							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-email" placeholder="Email" name="email" required>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-gender" class="col-lg-2 control-label">Gender</label>

							<div class="col-lg-10" id="contact-gender">
									<label class="radio-inline"><input type="radio" name="gender" value="M" required /> Male</label>
									<label class="radio-inline"><input type="radio" name="gender" value="F" required /> Female</label>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-gender" class="col-lg-2 control-label">Age</label>

							<div class="col-lg-10" >
								<select name="age" class="form-control">
									<option value="0-29">Under 30</option>
									<option value="30-60">Between 30 and 60</option>
									<option value="60+">Over 60</option>
								</select>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-Password" class="col-lg-2 control-label">Password</label>

							<div class="col-lg-10">
								<input type="password" class="form-control" id="contact-Password" placeholder="Password" name="password" required>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-morada" class="col-lg-2 control-label">Morada</label>

							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-morada" placeholder="Morada" name="morada" required>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-localidade" class="col-lg-2 control-label">Localidade</label>

							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-localidade" placeholder="Localidade" name="localidade" required>
							</div>
						</div>
						
						<div class="form-group">
							<label for="contact-cpostal" class="col-lg-2 control-label">C. Postal</label>

							<div class="col-lg-10">
								<input type="text" class="form-control" id="contact-cpostal" placeholder="Codigo Postal" name="cpostal" required>
							</div>
						</div>
						
						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
								<button type="submit" class="btn btn-primary">Register</button> 
							</div>
						</div> 

					</form>
					
				</div>

			</div>

		</section>

	</div> <!-- end container -->
<?php 	include('footer0.php'); ?>
