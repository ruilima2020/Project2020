
<?php

$hostname = "localhost";
$username = "root";
$password1 = "";
$dbname = "bestbuy";

//making the connection to mysql

$dbc = mysqli_connect($hostname, $username, $password1, $dbname) OR die("could not connect to database, ERROR: ".mysqli_connect_error());

//set encoding

mysqli_set_charset($dbc, "utf8");


// Start the session
session_start();

// Set session variables
if(!isset($_SESSION["user_id"])) $_SESSION["user_id"] = 0;
if(!isset($_SESSION["user_name"])) $_SESSION["user_name"] = '';
if(!isset($_SESSION["cart"])) $_SESSION["cart"] = array(array(),array());

// FUNCTIONS

function orders(){
	return count($_SESSION["cart"][0]);
}

function botoes($id){
	return '
			<td>
				<!-- Call to action buttons -->
				<ul class="list-inline m-0">
					<li class="list-inline-item">
						<a href="'.$_SERVER['PHP_SELF'].'?edit='.$id.'">
						<button class="btn btn-success btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></button>
						</a>
					</li>
					<li class="list-inline-item">
						<a href="'.$_SERVER['PHP_SELF'].'?del='.$id.'">
						<button class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></button>
						</a>
					</li>
				</ul>
			</td>
	';
}

function img50x60($img){
	return "<img src='../images/$img' width=50px height=60px />";
}

function img_cart($img){
	return "<img src='images/$img' width=55px height=68px />";
}

?>
