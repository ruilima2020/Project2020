<?php 	include('header0.php'); 

if(isset($_POST['menos'])){
	$pos=$_POST['pos'];
	$_SESSION['cart'][1][$pos]--;
	if($_SESSION['cart'][1][$pos]<1) $_SESSION['cart'][1][$pos]=1;
}else if(isset($_POST['mais'])){
	$pos=$_POST['pos'];
	$_SESSION['cart'][1][$pos]++;
}else if(isset($_GET['pos'])){
	$b=$_SESSION['cart'][0];
	$q=$_SESSION['cart'][1];
	$p=$_GET['pos'];
	$b1=$q1=array();
	for($i=0; $i<count($b); $i++){
		if($i != $p){
			array_push($b1,$b[$i]);
			array_push($q1,$q[$i]);
		}
	}
	$_SESSION['cart']=array($b1,$q1);
	header('location:cart.php');
}

$books=$_SESSION['cart'][0];
$qts=$_SESSION['cart'][1];

$cart="";
$subtotal=0;
for($i=0; $i<count($books); $i++){
	$r = mysqli_query($dbc, "SELECT * FROM books  WHERE id=".$books[$i]);
	$row = mysqli_fetch_array($r,MYSQLI_ASSOC);
	$cart.='
		<tr>
			<td>'.img_cart($row['imagem']).'</td>
			<td>'.$row['titulo'].'</td>
			<form action="cart.php" method="POST">
				<input type="hidden" name="pos" value="'.$i.'" />
				<td><button  type="submit" name="menos" class="btn1">-</button>'.$qts[$i].'<button type="submit" name="mais" class="btn1">+</button></td>
			</form>
			<td class="text-right">'.$row['preco']*$qts[$i].'€</td>
			<td class="text-right"><a href="cart.php?pos='.$i.'"><button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button></a></td>
		</tr>
	';
	$subtotal+=$row['preco']*$qts[$i];
}
$total=$subtotal+6.90;
?>
<!--Section: Block Content-->
<section>

 <div class="page-header" id="section-gallery">
	<h2>Check Your Cart</h2>
</div>

<div class="container mb-4">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col"> </th>
                            <th scope="col">Product</th>
                            <th scope="col" class="text-center">Quantity</th>
                            <th scope="col" class="text-right">Price</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
					<?=$cart;?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>Sub-Total</td>
                            <td class="text-right"><?=$subtotal;?>€</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>Shipping</td>
                            <td class="text-right">6.90€</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong>Total</strong></td>
                            <td class="text-right"><strong><?=$total;?>€</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col mb-2">
            <div class="row">
                <div class="col-sm-12  col-md-6">
                    <a href="themes.php"><button class="btn btn-block btn-light">Continue Shopping</button></a>
                </div>
                <div class="col-sm-12 col-md-6 text-right">
				<?php if($subtotal!=0)
                     echo '<a href="checkout.php?total='.$subtotal.'"><button class="btn btn-lg btn-block btn-success text-uppercase">Checkout</button></a>';
				?>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<p align="center"><b>Values shown for delivery in 7-14 days. The purchase will be sent to your address.</b></p>


</section>
<!--Section: Block Content-->

<?php 	include('footer0.php'); ?>
