﻿
#SET NAMES UTF8;
#CREATE DATABASE mydatabase CHARACTER SET utf8 COLLATE utf8_Unicode_ci;


DROP DATABASE IF EXISTS `bestbuy`;
CREATE DATABASE bestbuy;

USE bestbuy;

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(2) NOT NULL auto_increment,
  `nome` varchar(100) default '',
  PRIMARY KEY  (`id`)
);

INSERT INTO categorias(nome) VALUES ("Ficção"),("Romance");

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(11) NOT NULL auto_increment,
  `cat_id` int(2) NOT NULL,
  `titulo` varchar(100) default '',
  `descricao` mediumtext DEFAULT '',
  `imagem` varchar(100) default '',
  `preco` double(10,2) DEFAULT 0,
  PRIMARY KEY  (`id`)
);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(200) default '',
  `email` varchar(100) default '',
  `passe` varchar(50) default '',
  `gender` varchar(1) default '',
  `age` varchar(30) default '',
  `morada` varchar(200) default '',
  `cpostal` varchar(20) default '',
  `localidade` varchar(100) default '',
  PRIMARY KEY  (`id`)
);

DROP TABLE IF EXISTS `vendas`;
CREATE TABLE `vendas` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `data_hora` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	
  `valor` double(10,2) DEFAULT 0,
  PRIMARY KEY  (`id`)
);

DROP TABLE IF EXISTS `detalhes_vendas`;
CREATE TABLE `detalhes_vendas` (
  `id` int(11) NOT NULL auto_increment,
  `ven_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT 0,
  `preco` double(10,2) DEFAULT 0,
  PRIMARY KEY  (`id`)
);

DROP TABLE IF EXISTS `contactos`;
CREATE TABLE `contactos` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(100) default '',
  `email` varchar(100) default '',
  `msg` mediumtext DEFAULT '',
  PRIMARY KEY  (`id`)
);


