<?php 	include('header0.php'); 

$sales="";
$in=" in";
if(isset($_GET['user']) && isset($_GET['name'])){
	$r_v = mysqli_query($dbc, "SELECT * FROM vendas WHERE user_id=".$_GET['user']." ORDER BY data_hora DESC");
	$title="<h2>User Orders</h2><h3>".$_GET['name']."</h3>";
}else{ 
	$r_v = mysqli_query($dbc, "SELECT * FROM vendas ORDER BY data_hora DESC LIMIT 0,20");
	$title="<h2>Store Management - Recent Sales</h2>";
}
while($rv = mysqli_fetch_array($r_v)){
	$r_d = mysqli_query($dbc, "SELECT * FROM detalhes_vendas WHERE ven_id=".$rv['id']." ORDER BY preco");
	$cod="qa-".$rv['id'];
	$sales.='
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4 class="panel-title"><a href="#'.$cod.'" data-toggle="collapse" data-parent="#accordion-qa"><b>Date: </b>'.$rv['data_hora'].'&nbsp;&nbsp;&nbsp;&nbsp;  <b>Total: </b>'.$rv['valor'].'€ </a></h4>
				</div>
				<div class="panel-collapse collapse'.$in.'" id="'.$cod.'">
					<div class="panel-body">
						<table class="table">
						  <thead class="thead-dark">
							<tr>
							  <th scope="col">Book</th><th scope="col">Qty</th><th scope="col">Price</th>
							</tr>
						  </thead>
						  <tbody>
			';
	$in="";
	while($rd = mysqli_fetch_array($r_d)){
		$r_b=mysqli_query($dbc, "SELECT * FROM books WHERE id=".$rd['book_id']);
		$rb = mysqli_fetch_array($r_b,MYSQLI_ASSOC);
		$sales.='
				<tr>
				  <td>'.$rb['titulo'].'</td><td>'.$rd['qty'].'</td><td>'.($rd['preco']*$rd['qty']).'</td>
				</tr>
				';
	}
	$sales.='
			</tbody>
			</table>
		</div> <!-- end panel-body -->
	</div> <!-- end collapse -->
</div> <!-- end panel -->
	';
}

?>

		<div class="jumbotron">
		<div class="container text-center">
			<?=$title;?>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->

	<div class="container">

		<!-- About -->

		<section>
		
		<div class="panel-group" id="accordion-qa">
		<?=$sales;?>
		</div> <!-- end panel-group -->

		</section>


	</div> <!-- end container -->
