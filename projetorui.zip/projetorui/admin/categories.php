<?php 	
include('header0.php'); 

if($_SERVER['REQUEST_METHOD'] == 'POST'){

//grab all data from the submitted form:
$cat = $_POST['category'];

//check if all form values in variables are not empty:
	if(!empty($cat) ){
		
		if(isset($_GET['update'])) mysqli_query($dbc, "UPDATE categorias SET nome='$cat' WHERE id=".$_GET['update']);
		else mysqli_query($dbc, "INSERT INTO categorias(nome) VALUES('$cat')");
	}
}


if(isset($_GET['del'])) mysqli_query($dbc, "DELETE FROM categorias WHERE id=".$_GET['del']);

$result="";
$query = mysqli_query($dbc, "SELECT * FROM categorias ORDER BY nome");
while($row = mysqli_fetch_array($query)){
	$result.="<tr>
				<th scope='row'>".$row['id']."</th>
				<td>".$row['nome']."</td>
				".botoes($row['id'])."
			</tr>";
}

$nome_cat="";
$id_cat="";
$btn="Add Category";
if(isset($_GET['edit'])){
	$r = mysqli_query($dbc, "SELECT * FROM categorias  WHERE id=".$_GET['edit']);
	$row = mysqli_fetch_array($r,MYSQLI_ASSOC);
	$nome_cat=$row['nome'];
	$id_cat="?update=".$row['id'];
	$btn="Update Category";
}

?>

		<div class="jumbotron">
		<div class="container text-center">
			<h2>Store Management - Categories</h2>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->

	<div class="container">

		<section>
		
		<div class="row">

			<div class="col-lg-6">
				<form action="categories.php<?php echo $id_cat; ?>" method="POST" class="form-horizontal" role="form">
					<div class="form-group">
						<label for="contact-name" class="col-lg-2 control-label">Category</label>
						<div class="col-lg-6">
							<input type="text" class="form-control" id="contact-name" value="<?php echo $nome_cat; ?>" name="category" placeholder="Category Name" required>
						</div>
					</div>
					<div class="form-group">
						<div class="col-lg-10 col-lg-offset-2">
							<button type="submit" class="btn btn-primary"><?php echo $btn; ?></button> 
						</div>
					</div> 

				</form>

			</div>
			
			<div class="col-lg-6">
				
				<div class="row">
					<div class="col-lg-7 mx-auto">
						<div class="card border-0 shadow">
							<div class="card-body p-5">

								<!-- Responsive table -->
								<div class="table-responsive">
									<table class="table m-0">
										<thead>
											<tr>
												<th scope="col">Id</th><th scope="col">Category</th>
											</tr>
										</thead>
										<tbody>
										<?php echo $result; ?>
										</tbody>
									</table>

								</div>
							</div>
						</div>
					</div>
				
				</div>

			</div>
		</div>
		</section>


	</div> <!-- end container -->
<script>
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
</script>