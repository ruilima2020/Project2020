<?php 
include('../connection.php'); 

?>

<DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>BestBuy Solution - Admin</title>
	<meta name="description" content="BestBuy Solution">
	<meta name="author" content="Rui Lima">

	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


	<!-- Latest compiled and minified JavaScript -->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

	<style>
		.jumbotron{
			margin-top:-20px;
		}
		body{
			margin: 0 7px 0 7px;
		}

	</style>

</head>

<body>

	<!-- Navbar -->
	<nav class="navbar navbar-default navbar-fixe-top" id="main-navbar" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>

				<a href="index.php" class="navbar-brand"><img src="..\logo.jpg" alt="Feature Image" class="img-responsive"></a>

<br>
<br>

			</div> <!-- end navbar-header -->

				<div class="collapse navbar-collapse" id="navbar-collapse">
					<ul class="nav navbar-nav">
						<li><a href="categories.php">Categories</a></li>
						<li><a href="books.php">Books</a></li>
						<li><a href="index.php">Recent Sales</a></li>
						<li><a href="users.php">Users</a></li>
						<li><a href="contacts.php">Contacts</a></li>
					</ul>
					<a href="../" class="btn btn-success navbar-btn navbar-right">View Site</a>
				</div> <!-- end collapse -->
		</div> <!-- end container -->

	</nav>
	