<?php 	
include('header0.php'); 

if(isset($_GET['del'])) mysqli_query($dbc, "DELETE FROM books WHERE id=".$_GET['del']);

$title_book=$cat_id_book=$desc_book=$price_book=$form_get="";
$btn="Add Book";
if(isset($_GET['edit'])){
	$r = mysqli_query($dbc, "SELECT * FROM books  WHERE id=".$_GET['edit']);
	$row = mysqli_fetch_array($r,MYSQLI_ASSOC);
	$title_book=$row['titulo'];
	$cat_id_book=$row['cat_id'];
	$desc_book=$row['descricao'];
	$price_book=$row['preco'];
	$form_get="?update=".$row['id'];
	$btn="Update Book";
}


$cats="";
$query = mysqli_query($dbc, "SELECT * FROM categorias ORDER BY nome");
while($row = mysqli_fetch_array($query)){
	$sel=($cat_id_book==$row['id']?'selected':'');
	$cats.="<option $sel value='".$row['id']."'>".$row['nome']."</option>";
}

//check if user submitted form:
if($_SERVER['REQUEST_METHOD'] == 'POST'){

//grab all data from the submitted form:
$cat = $_POST['category'];
$title = $_POST['title'];
$description = $_POST['description'];
$img_name = $_FILES['imagem']['name'];
$img_tmp =$_FILES['imagem']['tmp_name'];
$price = $_POST['price'];

//check if all form values in variables are not empty:
	if(!empty($cat) && !empty($title) && !empty($description) && !empty($img_name) && !empty($price)){

		if(isset($_GET['update']))
			mysqli_query($dbc, "UPDATE books SET cat_id='$cat',titulo='$title',descricao='$description',imagem='$img_name',preco='$price' WHERE id=".$_GET['update']);
		else
			mysqli_query($dbc, "INSERT INTO books(cat_id,titulo,descricao,imagem,preco) VALUES('$cat','$title','$description','$img_name','$price')");
		
		move_uploaded_file($img_tmp,"../images/".$img_name);
		
	}
}

$books="";
$query = mysqli_query($dbc, "SELECT b.*, nome FROM books b,categorias c WHERE c.id=b.cat_id ORDER BY nome,titulo");
while($row = mysqli_fetch_array($query)){
	$books.='<tr>
				<td scope="row">'.$row['id'].'</td><td>'.$row['nome'].'</td>
				<td>'.$row['titulo'].'</td><td>'.img50x60($row['imagem']).'</td><td>'.$row['descricao'].'</td><td>'.$row['preco'].'</td>
				'.botoes($row['id']).'
			</tr>
			';
}

?>

		<div class="jumbotron">
		<div class="container text-center">
			<h2>Store Management - Books</h2>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->

	<div class="container">

		<section>
		
		<div class="row">

			<form action="books.php<?=$form_get;?>" method="POST" class="form-horizontal" role="form" enctype="multipart/form-data">
				
				<div class="form-group">
					<label for="contact-gender" class="col-lg-2 control-label">Category</label>
					<div class="col-lg-6" >
						<select name="category" class="form-control">
							<?php echo $cats; ?>
						</select>
					</div>
				</div>
				
				<div class="form-group">
					<label for="contact-name" class="col-lg-2 control-label">Title</label>
					<div class="col-lg-6">
						<input type="text" class="form-control" value="<?=$title_book;?>" id="contact-name" name="title" placeholder="Title" required>
					</div>
				</div>
				
				<div class="form-group">
					<label for="contact-msg" class="col-lg-2 control-label">Description</label>

					<div class="col-lg-6">
						<textarea id="contact-message" class="form-control" name="description" cols="30" rows="3" placeholder="Description"><?=$desc_book;?></textarea>
					</div>
				</div>

				<div class="form-group">
					<label for="contact-email" class="col-lg-2 control-label">Imagem</label>

					<div class="col-lg-6">
						<input type="file" class="form-control-file" id="contact-email" value="Choose file" name="imagem" required>
					</div>
				</div>
				
				<div class="form-group">
					<label for="contact-cpostal" class="col-lg-2 control-label">Price</label>

					<div class="col-lg-6">
						<input type="text" class="form-control" id="contact-cpostal" value="<?=$price_book;?>" placeholder="0.00€" name="price" required>
					</div>
				</div>
				
				<div class="form-group">
					<div class="col-lg-6 col-lg-offset-2">
						<button type="submit" class="btn btn-primary"><?=$btn;?></button> 
					</div>
				</div> 

			</form>

		</div>
			<hr>
				
		<div class="row">
				<div class="card border-0 shadow">
					<div class="card-body p-5">

						<!-- Responsive table -->
						<div class="table-responsive">
							<table class="table m-0">
								<thead>
									<tr>
										<th scope="col">Id</th><th scope="col">Category</th><th scope="col">Title</th><th scope="col">img</th><th scope="col">Description</th><th scope="col">Price</th>
									</tr>
								</thead>
								<tbody>
									<?=$books;?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
		</div>
		</section>


	</div> <!-- end container -->
<script>
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
</script>