<?php 	include('header0.php'); 

$users=$orders="";
$r_v = mysqli_query($dbc, "SELECT * FROM users ORDER BY nome");
while($rv = mysqli_fetch_array($r_v)){
	$r_b=mysqli_query($dbc, "SELECT count(*) as orders FROM vendas WHERE user_id=".$rv['id']);
	$rb = mysqli_fetch_array($r_b,MYSQLI_ASSOC);
	if($rb['orders'] > 0) $orders="<a href='index.php?user=".$rv['id']."&name=".$rv['nome']."'>Orders</a>";
	$users.='
		<div class="row panel">
			<div class="col-lg-4">
					<div class="panel-body">
						<p>'.$rv['nome'].'</p>
					</div>
			</div>
			<div class="col-lg-3">
					<div class="panel-body">
						<p>'.$rv['age'].' Years old</p>
					</div>
			</div>
			<div class="col-lg-3">
					<div class="panel-body">
						<p>'.$rv['cpostal'].' '.$rv['localidade'].'</p>
					</div>
			</div>
			<div class="col-lg-2">
					<div class="panel-body">
						'.$orders.'
					</div>
			</div>	
		</div>
	';
	$orders="";
}

?>

		<div class="jumbotron">
		<div class="container text-center">
			<h2>Users</h2>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->

	<div class="container">

		<!-- About -->

		<section>
		<?=$users;?>
		</section>


	</div> <!-- end container -->
