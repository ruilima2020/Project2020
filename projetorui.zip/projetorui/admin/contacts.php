<?php 	include('header0.php'); 

$contacts='
		<div class="row panel">
			<div class="col-lg-3">
					<div class="panel-body">
						<p><b>Name</b></p>
					</div>
			</div>
			<div class="col-lg-3">
					<div class="panel-body">
						<p><b>Email</b></p>
					</div>
			</div>
			<div class="col-lg-6">
					<div class="panel-body">
						<p><b>Message</b></p>
					</div>
			</div>
		</div>
';
$r_v = mysqli_query($dbc, "SELECT * FROM contactos ORDER BY nome");
while($rv = mysqli_fetch_array($r_v)){
	$contacts.='
		<div class="row panel">
			<div class="col-lg-3">
					<div class="panel-body">
						<p>'.$rv['nome'].'</p>
					</div>
			</div>
			<div class="col-lg-3">
					<div class="panel-body">
						<p>'.$rv['email'].'</p>
					</div>
			</div>
			<div class="col-lg-6">
					<div class="panel-body">
						<p>'.$rv['msg'].'</p>
					</div>
			</div>
		</div>
	';
}

?>

		<div class="jumbotron">
		<div class="container text-center">
			<h2>Contacts</h2>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->

	<div class="container">

		<!-- About -->

		<section>
		<?=$contacts;?>
		</section>


	</div> <!-- end container -->
