<?php 
error_reporting(0);
include('connection.php'); 
if(isset($_GET['logout'])){
	// remove all session variables
	session_unset();

	// destroy the session
	session_destroy();
}
$logout="";
if($_SESSION['user_id'] != 0) $logout=$_SESSION["user_name"]." - <a href='index.php?logout'>Logout</a>";;
?>

<DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>BestBuy Solution</title>
	<meta name="description" content="BestBuy Solution">
	<meta name="author" content="Rui Lima">

	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


	<!-- Latest compiled and minified JavaScript -->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

	<style>
		.jumbotron{
			margin-top:-20px;
		}
		body{
			margin: 0 7px 0 7px;
		}
		.btn1{
			margin: 0 9px 0 9px;
			width: 30px;
		}

	</style>

</head>

<body>

	<!-- Navbar -->
	<nav class="navbar navbar-inverse navbar-fixe-top" id="main-navbar" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>

				<a href="index.php" class="navbar-brand"><img src="logo.jpg" alt="Feature Image" class="img-responsive"></a>

<br>
<br>

			</div> <!-- end navbar-header -->

				<div class="collapse navbar-collapse" id="navbar-collapse">
					
					<ul class="nav navbar-nav">
					<?php if($_SESSION['user_id']==0) echo '<li><a href="login.php">Login</a></li>'; ?>
						<li><a href="register.php">Register</a></li>
						<li><a href="index.php#section-about">About us</a></li>
						<li><a href="index.php#section-testimonials">Testimonials</a></li>
						<li><a href="themes.php">Books</a></li>
						<li><a href="index.php#section-faq">F.A.Q.</a></li>
						<li><a href="index.php#section-contact">Contact</a></li>
					</ul>
					
					<div  class="navbar-right">
						<form action="themes.php" method="GET" class="form-inline my-2 my-lg-0">
							<div class="input-group input-group-sm">
								<input type="text" name="search" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" placeholder="Search..." required>
							</div>
							<button type="submit" class="btn btn-secondary btn-number">
								<i class="fa fa-search"></i>
							</button>
								
							<span>&nbsp;&nbsp;&nbsp;</span>
							<a class="btn btn-success btn-sm ml-3" href="cart.php">
								<i class="fa fa-shopping-cart"></i> Cart
								<span class="badge badge-light"><?php echo orders(); ?></span>
							</a>
						
							<span>&nbsp;&nbsp;&nbsp;</span>
							<span class="text-primary"><?=$logout;?></span>
						</form>
					</div>
						
				</div> <!-- end collapse -->
		</div> <!-- end container -->

	</nav>
	
		<div class="jumbotron">
		<div class="container text-center">
			<h1>The Best Books at the Best Prices!</h1>
			<p>Try our store and you will love it forever...</p>
		</div> <!-- end container -->
		</div> <!-- end jumbotron -->