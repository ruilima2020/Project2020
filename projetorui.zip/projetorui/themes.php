<?php 
include('header0.php'); 
$title="<h2>Books by Category. <small>Check the themes of our amazing books with some great examples!</small></h2>";
$themes="";
$r_cat = mysqli_query($dbc, "SELECT * FROM categorias ORDER BY nome");
$in=" in";
while($rowc = mysqli_fetch_array($r_cat)){
	if(isset($_GET['search'])){
		$txt=$_GET['search'];
		$title="<h2> Your title Search <i>'$txt'</i>. <small>Themes of Books by Category.</small></h2>";
		$r_books = mysqli_query($dbc, "SELECT * FROM books WHERE cat_id=".$rowc['id']." AND titulo LIKE '%$txt%' ORDER BY titulo");
	}else{
		$r_books = mysqli_query($dbc, "SELECT * FROM books WHERE cat_id=".$rowc['id']." ORDER BY titulo");
	}
	//Count the number of returned rows:
	$num = mysqli_num_rows($r_books);

	if($num > 0){
		$cod="qa-".$rowc['id'];
		$cod_ga="gallery-carousel-".$rowc['id'];
		$citem="item active";
		$themes.='<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#'.$cod.'" data-toggle="collapse" data-parent="#accordion-qa"> '.$rowc['nome'].' - '.$num.' book(s) </a></h4>
					</div>
					<div class="panel-collapse collapse'.$in.'" id="'.$cod.'">
							<div class="panel-body">
								<div class="carousel" id="'.$cod_ga.'">
									<div class="carousel-inner">
				';
		$in="";
		while($rb = mysqli_fetch_array($r_books)){
				$themes.='<div class="'.$citem.'">
							<img src="images/'.$rb['imagem'].'" alt="Slider image" images="">
							<div class="carousel-caption">
								<h2>'.$rb['titulo'].'</h2>
								<p>'.$rb['descricao'].'</p>
								<br><br>
								<h3>Price: '.$rb['preco'].'€</h3>
								<br><br>
								<a href="addcart.php?id='.$rb['id'].'" class="btn btn-success navbar-btn">Add this book to your cart </a>
							</div>
						</div>
				';
				$citem="item";
		}
		$themes.='		</div>
						<a href="#'.$cod_ga.'" class="left carousel-control" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left"></span>
						</a>
						<a href="#'.$cod_ga.'" class="right carousel-control" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right"></span>
						</a>

					</div>
				</div> <!-- end panel-body -->
			</div> <!-- end collapse -->
		</div> <!-- end panel -->
		';
	}
}

?>
		<section>
			<div class="page-header" id="section-gallery">
				<?=$title;?>
			</div>

<br>
<br>			
			<div class="panel-group" id="accordion-qa">
				<?php echo $themes; ?>
			</div> <!-- end panel-group -->
			
			
			<div class="row">
				<div class="col-lg-4">
					<div class="panel panel-default text-center">
						<div class="panel-body">
							<span class="glyphicon glyphicon-search"></span>
							<h4>Best Price!</h4>
							<p>We are the best solution with the best price currently on the market!</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="panel panel-default text-center">
						<div class="panel-body">
							<span class="glyphicon glyphicon-ok"></span>
							<h4>Best Quality!</h4>
							<p>You will be surprised by the quality of our products!</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="panel panel-default text-center">
						<div class="panel-body">
							<span class="glyphicon glyphicon-time"></span>
							<h4>Best Delivery Time</h4>
							<p>We have the best delivery time for your books!</p>
						</div>
					</div>
				</div>
			</div>
			
		</section>

<?php 	include('footer0.php'); 
?>
