<?php 	
include('header0.php'); 

if(isset($_GET['total'])){
	$subtotal=$_GET['total'];
}else{
	if(isset($_GET['finish'])){
		$sql="INSERT INTO vendas (user_id,data_hora,valor) VALUES (".$_SESSION['user_id'].",NOW(),".($_GET['finish']+6.9).")";
		//echo $sql;
		mysqli_query($dbc,$sql);
		$last_id = mysqli_insert_id($dbc);
		$books=$_SESSION['cart'][0];
		$qts=$_SESSION['cart'][1];

		$cart="";
		$subtotal=0;
		for($i=0; $i<count($books); $i++){
				$r = mysqli_query($dbc, "SELECT * FROM books  WHERE id=".$books[$i]);
				$rb = mysqli_fetch_array($r,MYSQLI_ASSOC);
				$price_book=$rb['preco'];
				mysqli_query($dbc, "INSERT INTO detalhes_vendas (ven_id,book_id,qty,preco) VALUES ($last_id,".$books[$i].",".$qts[$i].", $price_book)");
			}
		$_SESSION['cart']=array(array(),array());
	}
	header('location:themes.php');
}

$r = mysqli_query($dbc, "SELECT * FROM users  WHERE id=".$_SESSION['user_id']);
$row = mysqli_fetch_array($r,MYSQLI_ASSOC);
?>
	<div class="container">

		<section>
		<div class="page-header" id="section-gallery">
			<h2>Checkout</h2><p><b>Values shown for delivery in 7-14 days. The purchase will be sent to your address.</b></p>
		</div>
		
		<div class="row">

			<div class="col-lg-6">
				<h3>Your Address</h3>
				<br>
				<p><?php echo $row['nome'];?></p>
				<p><?php echo $row['morada'];?></p>
				<p><?php echo $row['localidade'];?></p>
				<p><?php echo $row['cpostal']." ".$row['localidade'];?></p>
			</div>
			
			<div class="col-lg-6">
				
				<div class="row">
					<div class="col-lg-7 mx-auto">
						<div class="card border-0 shadow">
							<div class="card-body p-5">

								<div class="table-responsive">
									<table class="table table-striped">
										<tbody>
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td>Sub-Total</td>
												<td class="text-right"><?=$subtotal;?>€</td>
											</tr>
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td>Shipping</td>
												<td class="text-right">6.90€</td>
											</tr>
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td><strong>Total</strong></td>
												<td class="text-right"><strong><?php echo ($subtotal+6.9);?>€</strong></td>
											</tr>
										</tbody>
									</table>
								</div>
								<div class="text-right">
									 <a href="checkout.php?finish=<?=$subtotal;?>" ><button class="btn btn-lg btn-block btn-success text-uppercase">Finish</button></a>
								</div>
							</div>
						</div>
					</div>
				
				</div>

			</div>
		</div>
		</section>


	</div> <!-- end container -->