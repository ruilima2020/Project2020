<?php
// Start the session
session_start();
if($_SESSION["user_id"] == 0){
	header("location:login.php?nologin");
}else{
	if(isset($_GET['id'])){
		$books=$_SESSION["cart"][0];
		$qts=$_SESSION["cart"][1];
		array_push($books,$_GET['id']);
		array_push($qts,1);
		$_SESSION["cart"]=array($books,$qts);
	}
	header('location:themes.php');
}
?>