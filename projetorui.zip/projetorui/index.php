<?php 	

include('header0.php'); 

$contact="";
//check if user submitted form:
if($_SERVER['REQUEST_METHOD'] == 'POST'){

//grab all data from the submitted form:
$cname = $_POST['nome'];
$cemail = $_POST['email'];
$cmsg = $_POST['msg'];

mysqli_query($dbc, "INSERT INTO contactos(nome,email,msg) VALUES('$cname','$cemail','$cmsg')");

$contact="<h4 style='color:green;'>thanks for contacting us, we will reply as soon as possible.</h4>";
}
?>

	<div class="container">

		<!-- About -->

		<section>

		<div class="page-header" id="section-about">
				<h2>About us. <small>BestBuy-Solution is a portuguese company created in January 2020, which the main goal is the total satisfaction of its costumers, by selling the best books at the best prices!
				The company is expanding strongly, and has been continuously increasing its range of offers! 
				Visit our amazing range of books, from Children's books to Love Books and enjoy our prices!
				Register on our website to stay up to date on our products and special discounts.
				BESTBUY-SOLUTION, always thinking about you!</small></h2>
		</div>

		</section>

<br>

		<!-- Testimonials -->
		
		<section> 

			<div class="page-header" id="section-testimonials">
				<h2>Testimonials. <small>This is the testimonials section.</small></h2>
			</div>

<br>
<br>

			<div class="row">	
				<div class="col-lg-4">
					<blockquote>
						<p>It's a great store and I love it since the beginning!</p>
					<footer>Marc Smith</footer>
					</blockquote>
				</div>
				<div class="col-lg-4">
					<blockquote>
						<p>Since I tried this store, I don't want another one!</p>
					<footer>Caroline Carter</footer>
					</blockquote>
				</div>
				<div class="col-lg-4">
					<blockquote>
						<p>Excellent store with excellent products at excellent prices!</p>
					<footer>Charles Dawson</footer>
					</blockquote>
				</div>
			</div> <!-- end row -->

<br>

				<p class="text-center"><em>Do you want to talk about our products? Click on the following button.</em></p>
				<p class="text-center"><a href="#section-contact" class="btn btn-default">Contact us</a></p>

		</section>

		
	</div> <!-- end container -->

<br>
<br>

	<div class="container">

<br>
<br>

		<!-- F.A.Q. -->
		<section>
			<div class="page-header" id="section-faq">
				<h2>Frequently Asked Questions <small>Some F.A.Q. of our Clients.</small></h2>
			</div> <!-- end page-header -->

<br>
<br>
		 
			<div class="panel-group" id="accordion-qa">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-1" data-toggle="collapse" data-parent="#accordion-qa">Question 1</a></h4>
					</div>
					<div class="panel-collapse collapse in" id="qa-1">
						<div class="panel-body">
							<b>Q:</b> How often do you have new books?; <b>A:</b> Usually weekly.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->

				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-2" data-toggle="collapse" data-parent="#accordion-qa">Question 2</a></h4>
					</div>
					<div class="panel-collapse collapse" id="qa-2">
						<div class="panel-body">
							<b>Q:</b> How long does it take to deliver a book that is not in stock?; <b>A:</b> 1 to 3 weeks.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->

				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="#qa-3" data-toggle="collapse" data-parent="#accordion-qa">Question 3</a></h4>
					</div>
					<div class="panel-collapse collapse" id="qa-3">
						<div class="panel-body">
							<b>Q:</b> Will BestBuy-Solution be able to order and deliver a book that is not in you product range?; <b>A:</b> Yes.
						</div> <!-- end panel-body -->
					</div> <!-- end collapse -->
				</div> <!-- end panel -->
			</div> <!-- end panel-group -->

		</section>

<br>
<br>

		<!-- Contact -->

		<section>

			<div class="page-header" id="section-contact">
				<h2>Contact us. <small>Let's stay in touch.</small></h2>
				<?=$contact;?>
			</div>

<br>
<br>

			<div class="row">

				<div class="col-lg-4">
					<p>To send us a message, use the contact form on the right.</p>

<br>
<br>

					<adress>
						<strong>BestBuy-Solution, Lda</strong><br>
						<br>Rua de Portugal, nº 1793, 9999-999, Lisbon, Portugal<br>
						<abbr title="Telephone">T: </abbr> 214999999; 919999999<br>
						<br>Opening Hours:<br>09h-18h00(Monday to Friday); 09h-13h00(Saturday)
					</adress>

				</div>
				<div class="col-lg-8">
					<form action="index.php#section-contact" method="POST" class="form-horizontal" role="form">
						<div class="form-group">
							<label for="contact-name" name="nome" class="col-lg-2 control-label">Name</label>

							<div class="col-lg-10">
								<input type="text" name="nome" class="form-control" id="contact-name" placeholder="Name" required>
							</div>
						</div>

						<div class="form-group">
							<label for="contact-email" class="col-lg-2 control-label">Email</label>

							<div class="col-lg-10">
								<input type="text"  name="email" class="form-control" id="contact-email" placeholder="Email" required>
							</div>
						</div>

						<div class="form-group">
							<label for="contact-msg" class="col-lg-2 control-label">Message</label>

							<div class="col-lg-10">
								<textarea name="msg" id="contact-message" class="form-control" cols="30" rows="10" placeholder="Message" required></textarea>
							</div>
						</div>

						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
								<button type="submit" class="btn btn-primary">Send Message</button> 
							</div>
						</div> 

					</form>
					
				</div>

			</div>

		</section>

	</div> <!-- end container -->
<?php 	include('footer0.php'); ?>
