<html>

<head>
<title></title>
</head>

<body>

<h3>Please Login to Enter</h3>

<form method="post" action="login.php">
	<p>Email:<input type="text" name="login_email" maxlength="50" /></p>
	<p>Password:<input type="password" name="login_password" maxlength="50"  /></p>	
	<p><input type="submit" value="Login" /></p>
</form>

<a href="userform.php">Register Here</a>

</body>

</html>
