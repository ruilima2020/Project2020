
<?php

$first_name = $_POST['fname'];
$last_name = $_POST['lname'];

echo "the first name is ".$first_name.", and last name is ".$last_name;

?> 

