<?php

	echo "<a href='output.php'>See Database Records</a> | <a href='password.php'>Change Password</a>";

?>
